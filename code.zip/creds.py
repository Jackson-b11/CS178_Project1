host = "project-one.cn9nbw41gsla.us-east-1.rds.amazonaws.com" # change to yours
user = "admin"
password = "I<3CS178!"  # change to yours
db = 'world' # change to yours

